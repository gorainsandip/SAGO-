SAGO STORE - EXACTLY 5 FILES

Files:
admin.html
index.html
login.html
style.css
README.txt

Firebase project: sago-ce761

SETUP:
1. Firebase Console > Authentication > Sign-in method > Email/Password ON.
2. Register/login from login.html and copy the UID shown.
3. Firestore > admins > Add document. Document ID = owner UID. Field role (string) = owner.
4. Additional admins: document ID = their UID, role = admin.
5. Upload all five files to the GitHub repository root.
6. GitHub Pages: Settings > Pages > Deploy from branch > main > /(root).
7. Website: https://gorainsandip.github.io/SAGO/

This version does not use Firebase Storage because Storage may require a billing account. Product images use public Image URLs.
Never put Firebase service-account/private keys in frontend files.
